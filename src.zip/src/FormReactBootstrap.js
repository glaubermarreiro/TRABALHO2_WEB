
import React from 'react';
import { Container, Row, Col, Button, Form } from 'react-bootstrap';

class FormReactBootstrap extends React.Component {
    render() {
        return (
            <Container>
                <h2>Enquiry Form</h2>
                <Row>
                    <Col sm={6}>
                        <Form>
                            <Form.Group controlId="FormGroupName">
                                <Form.Label>Name</Form.Label>
                                <Form.Control type="text" name="name" placeholder="Name" />
                            </Form.Group>
                            <Form.Group controlId="FormGroupEmail">
                                <Form.Label>Email</Form.Label>
                                <Form.Control type="email" name="email" placeholder="Email" />
                            </Form.Group>
                            <Form.Group controlId="FormGroupCity">
                                <Form.Label>City</Form.Label>
                                <Form.Control as="select">
                                    <option value="Fortaleza">Fortaleza</option>
                                    <option value="Maracanau">Maracanau</option>
                                </Form.Control>
                            </Form.Group>
                            <Form.Group controlId="FormGroupMessage">
                                <Form.Label>Message</Form.Label>
                                <Form.Control as="textarea" name="Message" />
                            </Form.Group>
                            <Form.Group>
                                <Button variant="success">Enviar Mensagem</Button>
                            </Form.Group>
                        </Form>
                    </Col>
                    <Col sm={6}>col-sm-6</Col>
                </Row>
            </Container>
        );
    }
}

export default FormReactBootstrap;
