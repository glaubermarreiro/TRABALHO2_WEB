import React from 'react'
import Main from '../templates/Main'

export default props =>
    <Main icon="home" title="Inicio" subtitle="Projeto Web Entregas">
        <div className="display-4">Seja Bem Vindo!</div>
        <hr />
        <p className="mb-0"> Sistema  de  Entregas Estilo Ifood</p>
    </Main>

