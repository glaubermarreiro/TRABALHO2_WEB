
import React from 'react';

class FormBootstrapAsDependency extends React.Component {
    render() {
        return (
            <div className="container">
                <h2>Enquiry Form</h2>
                <div className="row">
                    <div className="col-sm-6">
                        <form>
                            <div className="form-group">
                                <label for="Name">Name</label>
                                <input type="text" id="Name" className="form-control" />
                            </div>
                            <div className="form-group">
                                <label for="Email">Email</label>
                                <input type="text" id="Email" className="form-control" />
                            </div>
                            <div className="form-group">
                                <label for="City">City</label>
                                <select id="City" className="form-control">
                                    <option value="Fortaleza">Fortaleza</option>
                                    <option value="Maracanau">Maracanau</option>
                                </select>
                            </div>
                            <div className="form-group">
                                <label for="Message">Message</label>
                                <textarea id="Message" className="form-control" />
                            </div>
                            <div className="form-group">
                                <button className="btn btn-primary">Enviar Mensagem</button>
                            </div>
                        </form>
                    </div>
                    <div className="col-sm-6">
                        col-sm-6
          </div>
                </div>
            </div>
        )
    }
}

export default FormBootstrapAsDependency;
